extends CanvasLayer

signal start_game

var background
var msgLabel
var msgTimer
var scoreLabel
var timeLabel
var button

func _ready() -> void:
	background = $BlurBackground
	msgLabel = $MessageLabel
	msgTimer = $MessageTimer
	scoreLabel = $MarginContainer/ScoreLabel
	timeLabel = $MarginContainer/TimeLabel
	button = $StartButton

func update_score(value):
	scoreLabel.text = str(value)
	
func update_timer(value):
	timeLabel.text = str(value)
	
func show_message(text):
	msgLabel.text = text
	msgLabel.show()
	background.show()
	msgTimer.start()

func _on_message_timer_timeout() -> void:
	msgLabel.hide()
	background.hide()

func _on_button_pressed() -> void:
	msgLabel.hide()
	background.hide()
	button.hide()
	emit_signal("start_game")
	
func show_game_over():
	show_message("Game Over")
	
	await msgTimer.timeout
	
	button.show()
	msgLabel.text = "COIN DASH"
	msgLabel.show()
	background.show()
	


	
	
	
	
